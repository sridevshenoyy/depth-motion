# Depth Motion

Turn a Premiere Pro sequence of still images into a video with automatically alternating depth-based camera movements. Each image keeps its own duration, so you can arrange your pictures to match your audio first.

Depth Motion estimates depth from each image and creates the illusion of camera movement. It does not independently animate people or objects. The app creates a **silent MP4**; your original Premiere audio stays in your project.

> **Early test builds:** The Mac and Windows apps have each been tested on one computer. Their compatibility, signing, and third-party redistribution review are not complete. Please try a short preview before using them for a full project.

## Download and install

Find the downloads under **Releases** on this repository, if a release has been published. Download the installer for your computer; the two systems need different files.

### Mac

- **Supported test configuration:** Apple silicon (M1 or newer), macOS 26 or newer. Intel Macs and older macOS versions have not been supported or tested.
- Download **Depth Motion - Mac fixed test.pkg** and open the downloaded installer. Follow the installer instructions, then open **Depth Motion** from Applications.
- This test installer is **unsigned and not notarized**. macOS may warn about it or block installation; if it does, note the exact message before deciding what to do.
- The first render may need internet access to download an AI depth model. Image processing takes place on your Mac.

### Windows

- **Supported test configuration:** Windows 11, 64-bit. Tested on one Windows 11 PC with Intel UHD Graphics; compatibility with other computers and graphics hardware is not yet verified. Windows on ARM has not been tested.
- Download **Depth-Motion-0.2.0-Windows-Setup.exe**, open it, and follow the installer instructions. Then open **Depth Motion** from the Start menu.
- This test installer is **unsigned**. Windows may warn about it or block installation; if it does, note the exact message before deciding what to do.
- The tested installer includes the AI model and video tools and does not need internet for rendering. It uses the CPU to estimate depth and OpenGL graphics for the camera motion.

Each installer is roughly 400 MB, and rendering requires additional free disk space for temporary files and the finished video. Other operating systems have not been tested.

## Prepare your sequence in Premiere Pro

1. Arrange your still images in the order and durations you want, synced to your audio.
2. Work from a **copy** of the sequence with one uninterrupted, enabled video track of still images. The first image must start at the beginning. Remove video gaps, overlaps, transitions, nested sequences, and video clips from this copy. Empty video tracks and the original audio tracks can remain.
3. Use a progressive sequence with square pixels and even frame dimensions. Supported still images include PNG, JPEG, TIFF, BMP and WebP.
4. Select the sequence and choose **File → Export → Final Cut Pro XML**. Save the exported XML where you can find it. This is Premiere's legacy Final Cut Pro XML, not an `.fcpxml` file.
5. Keep the source images in the locations referenced by the XML. If you move a project to another computer, relink its media in Premiere and export a fresh XML there.

Depth Motion reads the XML and image files; it does not change your original Premiere project or the source images.

## Create your video

1. Open Depth Motion, click **Choose XML…**, and select the XML. Choose the sequence from the dropdown if needed.
2. Click **Create short preview** and save it with a new filename. The preview uses the first three images at their actual sequence durations.
3. Watch the preview. If it looks good, click **Generate full video** and choose a new filename. Progress advances as each image finishes. Leave the app open until it reports that the video is ready.
4. Import the finished MP4 into Premiere. Place it on a video track above your original still images, aligned with the sequence start. Keep the original audio tracks.
5. Scrub across the cuts and inspect the images before exporting. The output covers the stills beneath it while enabled and has no audio or transparency.

Five movement variations repeat across the images. Rendering speed depends on the images and computer; the first render may take longer.

## What to check

- Existing Premiere effects, transforms, cropping and opacity adjustments are not reproduced. Check the framing in the preview.
- Estimated depth can distort fine details such as hair, text and edges. Character movement is an illusion created by moving the virtual camera.
- Gaps, transitions, nested clips, missing images and multiple populated video tracks are not supported. If the app reports an error, simplify a copy of the sequence and export a new XML.
- The app does not overwrite an existing output video; choose a new filename.
- This prototype has no cancel button. If processing fails, check the error message and log path shown by the app.

## Project and build information

The `platforms/mac` folder contains the corrected Mac source, including its background helper. The `platforms/windows` folder contains the independently adapted Windows source, [build instructions](platforms/windows/BUILD.md), and [test report](platforms/windows/TEST-REPORT.md). The platform code and installers have not been merged into a single executable.

Large dependencies, models and prebuilt media tools are excluded from this source folder. The Mac build configuration expects additional media tools; its build provenance is not yet complete. The Windows build instructions describe how to obtain the required tools. Release installers, if published, are separate from the source files.

## Licensing and release status

A full third-party license and corresponding-source review remains unfinished. DepthFlow and ShaderFlow use AGPL licenses; the FFmpeg builds use GPL-enabled components; Qt, model files and other dependencies have their own terms. The available notices are a starting point, not a complete distribution compliance package. Broader testing, Mac signing and notarization, and Windows signing also remain outstanding.
