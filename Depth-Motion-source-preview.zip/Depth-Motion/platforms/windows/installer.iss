#define AppVersion "0.2.0"
#ifndef BundleDir
  #error BundleDir must point to the PyInstaller app folder
#endif
#ifndef OutputDir
  #error OutputDir must point to the deliverables folder
#endif
[Setup]
AppId={{1E716974-496B-4AC3-94AF-BD7158C8549F}
AppName=Depth Motion
AppVersion={#AppVersion}
AppPublisher=Depth Motion prototype
DefaultDirName={localappdata}\Programs\Depth Motion
DefaultGroupName=Depth Motion
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0.17763
OutputDir={#OutputDir}
OutputBaseFilename=Depth-Motion-0.2.0-Windows-Setup
Compression=lzma2/fast
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\Depth Motion.exe
SetupLogging=yes
CloseApplications=yes
[Files]
Source: "{#BundleDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
[InstallDelete]
Type: files; Name: "{app}\_internal\icuuc.dll"
Type: files; Name: "{app}\_internal\icudt78.dll"
Type: files; Name: "{app}\_internal\ucrtbase.dll"
Type: files; Name: "{app}\_internal\api-ms-*.dll"
[Icons]
Name: "{group}\Depth Motion"; Filename: "{app}\Depth Motion.exe"
Name: "{group}\Uninstall Depth Motion"; Filename: "{uninstallexe}"
[Run]
Filename: "{app}\Depth Motion.exe"; Description: "Open Depth Motion"; Flags: nowait postinstall skipifsilent
