"""Copy installed dependency license files into a reviewable local notice pack."""
from importlib.metadata import distributions
import json
from pathlib import Path
import shutil

root = Path(__file__).parent
dest = root / 'Third party notices'
dest.mkdir(exist_ok=True)
inventory=[]
for dist in distributions():
    name = dist.metadata['Name']
    entry={'name':name,'version':dist.version,'license':dist.metadata.get('License-Expression') or dist.metadata.get('License',''),'copied_files':[]}
    for file in dist.files or []:
        if '.dist-info/' not in str(file).replace('\\','/'):
            continue
        if not any(s in str(file).lower() for s in ('license','copying','notice','authors')):
            continue
        source=Path(dist.locate_file(file))
        if source.is_file():
            relative = str(file).replace('\\','/').split('.dist-info/', 1)[1]
            target=dest/name/relative
            target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(source,target)
            entry['copied_files'].append(str(target.relative_to(dest)))
    inventory.append(entry)
(dest/'inventory.json').write_text(json.dumps(inventory,indent=2),encoding='utf-8')
print(f'Collected notices for {len(inventory)} installed distributions')
