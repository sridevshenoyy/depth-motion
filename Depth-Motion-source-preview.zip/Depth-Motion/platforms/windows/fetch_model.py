"""Build-time only: obtain a pinned local copy of Depth Anything V2 Small."""
import hashlib
import json
from pathlib import Path
from huggingface_hub import snapshot_download

repo = 'depth-anything/Depth-Anything-V2-Small-hf'
revision = '5426e4f0f36572d16453bbda7a8389317b1bef99'
destination = Path(__file__).parent / 'vendor' / 'model'
snapshot_download(repo, revision=revision, local_dir=destination,
                  allow_patterns=['config.json', 'preprocessor_config.json', 'model.safetensors', 'README.md', 'LICENSE*'])
files = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in destination.iterdir() if p.is_file()}
(destination / 'provenance.json').write_text(json.dumps({'repo':repo,'revision':revision,'sha256':files},indent=2),encoding='utf-8')
print(f'Model ready: {revision}')
