# Windows 0.2.0 build

Tested on this PC with Python 3.12.14 x64 and the exact packages in requirements-windows.lock.txt. Use a short build path to avoid Windows filename limits. No Visual Studio or CUDA installation is needed; compatible binary wheels are used. CPU runs the AI estimator; the OpenGL graphics adapter renders the motion.

1. Install Python 3.12 x64 and Inno Setup from python.org and jrsoftware.org (or supply existing executable paths).
2. Download the FFmpeg 9.0.2 essentials Windows release from https://github.com/GyanD/codexffmpeg/releases/tag/9.0.2 . Extract bin/ffmpeg.exe and bin/ffprobe.exe into vendor/win64 next to this file. The tested archive SHA256 is recorded in BUILD-PROVENANCE.json.
3. Run build-windows.ps1 with -Python312 pointing to python.exe, -InnoCompiler pointing to ISCC.exe, and a short -BuildRoot path. It creates an isolated environment, installs the pinned Windows packages, fetches the pinned model, runs parser tests, freezes the two executables and compiles the installer.
4. Verify a fresh installed build using the sample XML files, both preview and full render, before relying on it.

Depth Anything V2 Small is pinned to revision 5426e4f0f36572d16453bbda7a8389317b1bef99 of depth-anything/Depth-Anything-V2-Small-hf. fetch_model.py downloads the four required model files. The installer includes them; model access at runtime is local_files_only. Preserve model provenance and notices in any build.

DepthMotionEngine.exe is a console helper so Qt can receive UTF-8 progress on Windows. The GUI launches it without a console. Keeping the helper separate avoids PyInstaller's documented Windows windowed-build stdout limitation: https://pyinstaller.org/en/stable/common-issues-and-pitfalls.html . Do not replace the helper with the windowed GUI executable.

The engine supports `--depth-motion-cli inspect input.xml` and `--depth-motion-cli render input.xml --output new.mp4 --work-dir jobs`. Add `--preview-clips 3` for the first-three-image preview. It refuses an existing output filename. Cached completed clips are validated and reused on retry. An incomplete private partial clip is rebuilt.

Source-only archive omits the large model, FFmpeg, and Python libraries. The installer bundles them. The original supplied prototype and Mac dependency reference are retained separately in the working folder; Windows uses its own lock file and spec.

Third-party notices are collected from installed package metadata; this is not a complete redistribution compliance audit. DepthFlow and ShaderFlow use AGPL, this FFmpeg build is GPL-enabled, and Qt uses its own license terms. Before sharing outside personal testing, review complete corresponding-source, notice, and license requirements. Signing and testing on additional PCs remain outstanding.
