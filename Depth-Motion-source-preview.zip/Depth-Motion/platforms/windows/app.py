"""Depth Motion: a small desktop front end for the local sequence renderer."""
import json
import os
import sys
from pathlib import Path

# Bundled media tools live in the app rather than depending on a user's PATH.
if getattr(sys, 'frozen', False):
    tools_dir = Path(sys._MEIPASS) / 'media-tools'
    os.environ['PATH'] = str(tools_dir) + os.pathsep + os.environ.get('PATH', '')

if len(sys.argv) > 1 and sys.argv[1] == '--depth-motion-worker':
    sys.argv.pop(1)
    from core.worker import main
    sys.exit(main())
if len(sys.argv) > 1 and sys.argv[1] == '--depth-motion-cli':
    sys.argv.pop(1)
    from core.cli import main
    sys.exit(main())

from PySide6.QtCore import QProcess, QStandardPaths
from PySide6.QtWidgets import (QApplication, QComboBox, QFileDialog, QHBoxLayout,
    QLabel, QLineEdit, QMainWindow, QMessageBox, QProgressBar, QPushButton,
    QTextEdit, QVBoxLayout, QWidget)


class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Depth Motion')
        self.resize(680, 570)
        self.process = None
        self.buffer = b''
        self.action = None
        self.timeline = None
        self.output = ''
        page = QWidget()
        self.setCentralWidget(page)
        layout = QVBoxLayout(page)
        title = QLabel('Depth Motion')
        title.setStyleSheet('font-size: 25px; font-weight: 700;')
        layout.addWidget(title)
        desc = QLabel('Turn your timed still images into depth-based 3D motion. Your images stay on this computer.')
        desc.setWordWrap(True)
        layout.addWidget(desc)
        helptext = QLabel('In Premiere: select your sequence, then choose File → Export → Final Cut Pro XML. Choose that XML below.')
        helptext.setWordWrap(True)
        layout.addWidget(helptext)
        row = QHBoxLayout()
        self.source = QLineEdit()
        self.source.setPlaceholderText('Choose your Premiere XML file')
        self.source.setReadOnly(True)
        self.browse = QPushButton('Choose XML…')
        self.browse.clicked.connect(self.choose_xml)
        row.addWidget(self.source, 1)
        row.addWidget(self.browse)
        layout.addLayout(row)
        row = QHBoxLayout()
        row.addWidget(QLabel('Sequence'))
        self.sequences = QComboBox()
        self.sequences.currentIndexChanged.connect(self.inspect)
        row.addWidget(self.sequences, 1)
        layout.addLayout(row)
        self.details = QLabel('Choose an XML file to check your sequence.')
        self.details.setWordWrap(True)
        layout.addWidget(self.details)
        note = QLabel('Output is a silent video. Put it above the original images in Premiere to keep your audio and timing. This version supports a single track of still images without gaps, transitions or other effects.')
        note.setWordWrap(True)
        layout.addWidget(note)
        self.progress = QProgressBar()
        self.progress.setValue(0)
        layout.addWidget(self.progress)
        self.log = QTextEdit()
        self.log.setReadOnly(True)
        layout.addWidget(self.log, 1)
        buttons = QHBoxLayout()
        self.preview = QPushButton('Create short preview')
        self.start = QPushButton('Generate full video')
        self.preview.setEnabled(False)
        self.start.setEnabled(False)
        self.preview.clicked.connect(lambda: self.choose_output(True))
        self.start.clicked.connect(lambda: self.choose_output(False))
        buttons.addWidget(self.preview)
        buttons.addWidget(self.start)
        layout.addLayout(buttons)

    def command(self):
        if getattr(sys, 'frozen', False):
            return [str(Path(sys.executable).with_name('DepthMotionEngine.exe'))]
        return [sys.executable, str(Path(__file__).resolve())]

    def execute(self, action, args):
        if self.process is not None:
            return
        self.action, self.buffer = action, b''
        self.process = QProcess(self)
        self.process.setProgram(self.command()[0])
        self.process.setArguments(self.command()[1:] + ['--depth-motion-cli', action] + args)
        self.process.setWorkingDirectory(str(Path(__file__).resolve().parent))
        self.process.readyReadStandardOutput.connect(self.read_stdout)
        self.process.readyReadStandardError.connect(self.read_stderr)
        self.process.errorOccurred.connect(self.process_error)
        self.process.finished.connect(self.finished)
        self.browse.setEnabled(False)
        self.sequences.setEnabled(False)
        self.preview.setEnabled(False)
        self.start.setEnabled(False)
        self.process.start()

    def choose_xml(self):
        filename, _ = QFileDialog.getOpenFileName(self, 'Choose Premiere XML', '', 'XML files (*.xml)')
        if filename:
            self.source.setText(filename)
            self.timeline = None
            self.details.setText('Checking sequence…')
            self.sequences.clear()
            self.execute('sequences', [filename])

    def inspect(self):
        if self.process or not self.source.text() or not self.sequences.currentText():
            return
        self.timeline = None
        self.details.setText('Checking sequence…')
        self.execute('inspect', [self.source.text(), '--sequence', self.sequences.currentText()])

    def choose_output(self, preview):
        default = 'Depth Motion preview.mp4' if preview else 'Depth Motion.mp4'
        filename, _ = QFileDialog.getSaveFileName(self, 'Save video as', default, 'MP4 video (*.mp4)')
        if not filename:
            return
        if not filename.lower().endswith('.mp4'):
            filename += '.mp4'
        if Path(filename).exists():
            QMessageBox.warning(self, 'Choose a new name', 'Please choose a new filename; existing videos are not replaced.')
            return
        self.output = filename
        folder = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.AppLocalDataLocation)
        work = Path(folder) / 'jobs'
        work.mkdir(parents=True, exist_ok=True)
        args = [self.source.text(), '--sequence', self.sequences.currentText(), '--output', filename, '--work-dir', str(work)]
        if preview:
            args += ['--preview-clips', '3']
        self.progress.setValue(0)
        self.log.append('Creating depth motion with the included local model. Progress advances after each image; the first render can take longer.')
        self.execute('render', args)

    def read_stdout(self):
        self.buffer += bytes(self.process.readAllStandardOutput())
        while b'\n' in self.buffer:
            line, self.buffer = self.buffer.split(b'\n', 1)
            try:
                data = json.loads(line.decode('utf-8'))
            except (ValueError, UnicodeError):
                continue
            kind = data.get('type')
            if kind == 'sequences':
                self.sequences.blockSignals(True)
                self.sequences.clear()
                self.sequences.addItems(data.get('names', []))
                self.sequences.blockSignals(False)
            elif kind == 'timeline':
                self.timeline = data
                total = sum(c['duration_frames'] for c in data['clips'])
                seconds = total * data['fps_den'] / data['fps_num']
                self.details.setText(f"{len(data['clips'])} images · {data['width']} × {data['height']} · {data['fps_num']}/{data['fps_den']} fps · {total} frames ({seconds:.3f} s)")
                for warning in data.get('warnings', []):
                    self.log.append('Note: ' + warning)
            elif kind == 'progress':
                self.progress.setMaximum(data['total'])
                self.progress.setValue(data['done'])
                self.log.append(f"{data['done']} of {data['total']}: {data['name']}")
            elif kind == 'error':
                self.log.append('Error: ' + data.get('message', 'Unknown error'))
            elif kind == 'complete':
                self.log.append('Finished: ' + data['output'])
                QMessageBox.information(self, 'Video ready', 'Your depth-motion video is ready:\n' + data['output'])

    def read_stderr(self):
        message = bytes(self.process.readAllStandardError()).decode('utf-8', errors='replace').strip()
        if message:
            self.log.append(message[-1500:])

    def process_error(self, error):
        if self.process:
            self.log.append('Could not start the processor: ' + self.process.errorString())
            if error == QProcess.ProcessError.FailedToStart:
                self.finished(1, QProcess.ExitStatus.CrashExit)

    def finished(self, code, status):
        self.read_stdout()
        old_action = self.action
        self.process.deleteLater()
        self.process = None
        self.browse.setEnabled(True)
        self.sequences.setEnabled(True)
        if code and old_action in ('sequences', 'inspect'):
            self.details.setText('This sequence could not be used. See the message below.')
        if old_action == 'sequences' and code == 0:
            self.inspect()
            return
        self.preview.setEnabled(self.timeline is not None)
        self.start.setEnabled(self.timeline is not None)
        if code and old_action == 'render':
            self.log.append('Generation stopped. Completed clips remain available for a retry.')

    def closeEvent(self, event):
        if self.process is not None:
            QMessageBox.information(self, 'Still working', 'Please wait until the current task finishes before closing the app.')
            event.ignore()
        else:
            event.accept()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setApplicationName('Depth Motion')
    window = Window()
    window.show()
    if len(sys.argv) == 2 and sys.argv[1].lower().endswith('.xml'):
        window.source.setText(str(Path(sys.argv[1]).resolve()))
        window.execute('sequences', [window.source.text()])
    sys.exit(app.exec())
