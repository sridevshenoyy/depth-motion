param(
    [Parameter(Mandatory=$true)][string]$Python312,
    [Parameter(Mandatory=$true)][string]$InnoCompiler,
    [string]$BuildRoot = "$env:LOCALAPPDATA\DepthMotionBuild"
)
$ErrorActionPreference = 'Stop'
$sourceRoot = $PSScriptRoot
New-Item -ItemType Directory -Path $BuildRoot -Force | Out-Null
$env:TEMP = Join-Path $BuildRoot 'temp'
$env:TMP = $env:TEMP
New-Item -ItemType Directory -Path $env:TEMP -Force | Out-Null
$env:PYTHONUTF8 = '1'
function Check-Exit { if ($LASTEXITCODE -ne 0) { throw "Build step failed ($LASTEXITCODE)" } }
& $Python312 -m venv (Join-Path $BuildRoot 'env'); Check-Exit
$python = Join-Path $BuildRoot 'env\Scripts\python.exe'
& $python -m pip install -r (Join-Path $sourceRoot 'requirements-windows.lock.txt') --extra-index-url https://download.pytorch.org/whl/cpu; Check-Exit
& $python (Join-Path $sourceRoot 'fetch_model.py'); Check-Exit
if (-not (Test-Path (Join-Path $sourceRoot 'vendor\win64\ffmpeg.exe'))) {
    throw 'Put the FFmpeg 9.0.2 Windows essentials ffmpeg.exe and ffprobe.exe in vendor\win64. See BUILD.md.'
}
Push-Location $sourceRoot
try {
    & $python -m unittest core.test_timeline; Check-Exit
    & $python collect_notices.py; Check-Exit
    & $python -m PyInstaller --noconfirm --distpath (Join-Path $BuildRoot 'dist') --workpath (Join-Path $BuildRoot 'build') DepthMotion-Windows.spec; Check-Exit
    $bundle = Join-Path $BuildRoot 'dist\Depth Motion'
    & $python stage-windows.py $bundle; Check-Exit
    Copy-Item 'Third party notices' $bundle -Recurse -Force
    Copy-Item 'THIRD_PARTY_NOTES.txt' $bundle -Force
    $out = Join-Path $sourceRoot 'installer-output'
    & $InnoCompiler "/DBundleDir=$bundle" "/DOutputDir=$out" installer.iss; Check-Exit
} finally { Pop-Location }
