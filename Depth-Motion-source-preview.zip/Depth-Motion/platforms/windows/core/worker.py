"""Render one clip in an isolated process to avoid GPU state buildup."""
from __future__ import annotations
import argparse
import math
import os
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--image', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--width', type=int, required=True)
    parser.add_argument('--height', type=int, required=True)
    parser.add_argument('--frames', type=int, required=True)
    parser.add_argument('--fps-num', type=int, required=True)
    parser.add_argument('--fps-den', type=int, required=True)
    parser.add_argument('--variant', type=int, required=True)
    args = parser.parse_args()
    from attrs import define
    from depthflow.scene import DepthScene
    from depthflow.estimators.anything import DepthAnythingV2
    from PIL import Image, ImageOps
    from shaderflow.shader import WATCHDOG
    import torch

    # CPU inference keeps the installer independent of CUDA and GPU driver versions.
    # OpenGL still renders the depth movement on the available graphics adapter.
    torch.set_num_threads(min(4, os.cpu_count() or 1))
    root = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent.parent))
    model_dir = root / 'vendor' / 'model'
    if not (model_dir / 'model.safetensors').is_file():
        raise RuntimeError('The bundled depth model is missing. Reinstall Depth Motion or run fetch_model.py when building from source.')

    class LocalDepth(DepthAnythingV2):
        def load_model(self):
            if self.model not in self._pipelines:
                from transformers.models.depth_anything.modeling_depth_anything import DepthAnythingForDepthEstimation
                from transformers.models.dpt.image_processing_dpt import DPTImageProcessor
                self._pipelines[self.model] = DepthAnythingForDepthEstimation.from_pretrained(
                    model_dir, local_files_only=True).to('cpu').eval()
                self._processor[self.model] = DPTImageProcessor.from_pretrained(model_dir, local_files_only=True)

        def _estimate(self, image):
            with torch.inference_mode():
                inputs = self._processor[self.model](images=image, return_tensors='pt')
                return self._pipelines[self.model](**inputs).predicted_depth.cpu().numpy()[0]

    @define
    class Motion(DepthScene):
        def update(self):
            t = self.cycle
            self.state.isometric = 0.6
            self.state.steady = 0.3
            if args.variant == 0:
                self.state.offset = (0.45 * math.sin(t + math.pi / 2), 0.45 * math.sin(t))
            elif args.variant == 1:
                self.state.offset = (0.65 * math.sin(t), 0.0)
            elif args.variant == 2:
                self.state.offset = (0.0, 0.55 * math.sin(t))
            elif args.variant == 3:
                self.state.focus = 0.35
                self.state.zoom = 0.97
                self.state.isometric = 0.45 * math.cos(t) + 0.65
                self.state.offset = (0.40 * math.sin(t), 0.0)
            else:
                self.state.offset = (0.40 * math.sin(t + math.pi), 0.35 * math.sin(t + math.pi / 2))

    scene = Motion(backend='headless', estimator=LocalDepth())
    scene.ffmpeg.h264(preset='veryfast')
    with Image.open(args.image) as source:
        image = ImageOps.exif_transpose(source).convert('RGB')
    try:
        scene.input(image=image)
        scene.main(output=args.output, width=args.width, height=args.height,
                   fps=args.fps_num / args.fps_den,
                   time=args.frames * args.fps_den / args.fps_num, ssaa=1.0)
    finally:
        # Shader live-reload has no purpose in an isolated export worker and can
        # keep Windows workers alive after a successful render.
        WATCHDOG.stop()
        WATCHDOG.join(timeout=5)
        if scene.window is not None:
            scene.window.destroy()


if __name__ == '__main__':
    main()
