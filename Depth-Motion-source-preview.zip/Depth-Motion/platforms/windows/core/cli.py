"""CLI used by the app; outputs one JSON object per line."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

from .timeline import TimelineError, read_timeline, read_manifest, sequence_names


def emit(kind, **data):
    print(json.dumps({'type': kind, **data}, ensure_ascii=False), flush=True)


def frames(path, ffprobe):
    p = subprocess.run([ffprobe, '-v', 'error', '-select_streams', 'v:0',
                        '-show_entries', 'stream=nb_frames', '-of', 'csv=p=0', str(path)],
                       capture_output=True, text=True, check=True)
    return int(p.stdout.strip())


def worker_cmd():
    if getattr(sys, 'frozen', False):
        return [sys.executable, '--depth-motion-worker']
    return [sys.executable, '-m', 'core.worker']


def render(timeline, destination, work_dir, limit=None):
    ffmpeg, ffprobe = shutil.which('ffmpeg'), shutil.which('ffprobe')
    if not ffmpeg or not ffprobe:
        raise TimelineError('FFmpeg and FFprobe are required. Install them or include them with the app.')
    destination = Path(destination).expanduser().resolve()
    if destination.exists():
        raise TimelineError('The output file already exists. Choose a new name to protect it.')
    if destination.suffix.lower() != '.mp4':
        raise TimelineError('The output filename must end in .mp4.')
    if not destination.parent.is_dir():
        raise TimelineError('The output folder does not exist.')
    data = timeline.dictionary()
    if limit:
        data['clips'] = data['clips'][:limit]
    signature = {'version': 2, 'timeline': data,
                 'sources': [[c['path'], os.stat(c['path']).st_size, os.stat(c['path']).st_mtime_ns]
                             for c in data['clips']]}
    digest = hashlib.sha256(json.dumps(signature, sort_keys=True).encode()).hexdigest()[:20]
    directory = Path(work_dir).expanduser().resolve() / digest
    directory.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    cache = str(Path(work_dir).expanduser().resolve() / 'cache')
    env.update(XDG_CACHE_HOME=cache, XDG_DATA_HOME=cache, HF_HOME=str(Path(cache) / 'huggingface'),
               PYTHONUTF8='1', HF_HUB_DISABLE_SYMLINKS_WARNING='1')
    if not getattr(sys, 'frozen', False):
        root = str(Path(__file__).resolve().parent.parent)
        env['PYTHONPATH'] = os.pathsep.join(x for x in (root, env.get('PYTHONPATH')) if x)
    outputs = []
    for index, clip in enumerate(data['clips'], 1):
        output = directory / f'{index:05d}.mp4'
        if output.exists():
            try:
                valid = frames(output, ffprobe) == clip['duration_frames']
            except (ValueError, subprocess.SubprocessError):
                valid = False
            if not valid:
                raise TimelineError(f'An incomplete previous clip exists in the work folder: {output}. Move it elsewhere and retry.')
        else:
            temporary = directory / f'{index:05d}.partial.mp4'
            # Only remove our own unfinished clip; source images and completed clips are untouched.
            temporary.unlink(missing_ok=True)
            cmd = worker_cmd() + ['--image', clip['path'], '--output', str(temporary),
                  '--width', str(data['width']), '--height', str(data['height']),
                  '--frames', str(clip['duration_frames']), '--fps-num', str(data['fps_num']),
                  '--fps-den', str(data['fps_den']), '--variant', str((index-1) % 5)]
            logpath = directory / f'{index:05d}.log'
            with logpath.open('w', encoding='utf-8') as log:
                result = subprocess.run(cmd, env=env, stdout=log, stderr=subprocess.STDOUT,
                                        creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
            if result.returncode:
                raise TimelineError(f"Rendering image {index} failed. Details: {logpath}")
            if frames(temporary, ffprobe) != clip['duration_frames']:
                raise TimelineError(f'The frame count did not match for image {index}.')
            temporary.rename(output)
        outputs.append(output)
        emit('progress', done=index, total=len(data['clips']), name=clip['name'])
    # Use a temporary concat list and explicitly quote ffmpeg concat syntax.
    listfile = directory / 'concat.txt'
    listfile.write_text(''.join("file '" + p.as_posix().replace("'", "'\\''") + "'\n" for p in outputs), encoding='utf-8')
    fd, tempname = tempfile.mkstemp(prefix='.depth-motion-', suffix='.mp4', dir=destination.parent)
    os.close(fd)
    os.unlink(tempname)
    try:
        subprocess.run([ffmpeg, '-v', 'error', '-n', '-f', 'concat', '-safe', '0', '-i', str(listfile),
                        '-c', 'copy', tempname], check=True, capture_output=True)
        expected = sum(c['duration_frames'] for c in data['clips'])
        if frames(tempname, ffprobe) != expected:
            raise TimelineError('The combined video frame count did not match the timeline.')
        # Exclusive creation avoids overwriting existing data and works on Windows
        # filesystems where hard links may be unavailable.
        created = False
        try:
            with open(tempname, 'rb') as source, open(destination, 'xb') as target:
                created = True
                shutil.copyfileobj(source, target, length=1024 * 1024)
        except BaseException:
            if created:
                destination.unlink(missing_ok=True)
            raise
    finally:
        if os.path.exists(tempname):
            os.unlink(tempname)
    emit('complete', output=str(destination), frames=expected, clips=len(outputs), audio=False)


def main():
    parser = argparse.ArgumentParser(description='Create depth-motion videos from a Premiere Final Cut Pro XML export.')
    sub = parser.add_subparsers(dest='action', required=True)
    ls = sub.add_parser('sequences')
    ls.add_argument('xml')
    for name in ('inspect', 'render'):
        cmd = sub.add_parser(name)
        cmd.add_argument('xml')
        cmd.add_argument('--sequence')
        if name == 'render':
            cmd.add_argument('--output', required=True)
            cmd.add_argument('--work-dir', required=True)
            cmd.add_argument('--preview-clips', type=int)
    args = parser.parse_args()
    try:
        if args.action == 'sequences':
            emit('sequences', names=sequence_names(args.xml))
        else:
            timeline = (read_manifest(args.xml) if Path(args.xml).suffix.lower() == '.json'
                        else read_timeline(args.xml, args.sequence))
            emit('timeline', **timeline.dictionary())
            if args.action == 'render':
                if args.preview_clips is not None and args.preview_clips < 1:
                    raise TimelineError('Preview length must be at least one image.')
                render(timeline, args.output, args.work_dir, args.preview_clips)
    except (TimelineError, OSError, subprocess.SubprocessError, ValueError) as exc:
        emit('error', message=str(exc))
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
