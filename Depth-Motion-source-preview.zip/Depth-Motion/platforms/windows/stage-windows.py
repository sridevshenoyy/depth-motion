"""Ensure native runtime files are complete and cannot shadow Windows ICU."""
from pathlib import Path
import shutil
import sys
from PyInstaller.utils.hooks import get_package_paths

bundle=Path(sys.argv[1]).resolve()
internal=bundle/'_internal'
if not (bundle/'Depth Motion.exe').is_file() or not internal.is_dir():
    raise RuntimeError('Expected a Depth Motion build folder')
for package in ('torchvision','glfw'):
    source=Path(get_package_paths(package)[1])
    target=internal/package
    target.mkdir(exist_ok=True)
    for pattern in ('*.pyd','*.dll'):
        for p in source.glob(pattern):
            shutil.copyfile(p,target/p.name)
# Qt uses the ICU shim supplied by Windows. Build-host tools such as Poppler
# may provide an unrelated icuuc.dll through PATH; it must never shadow the OS
# shim. Likewise, Windows 10/11 supply UCRT and API-set forwarders themselves.
for p in internal.iterdir():
    name=p.name.lower()
    if p.is_file() and (name in {'icuuc.dll','icudt78.dll','ucrtbase.dll'} or (name.startswith('api-ms-') and name.endswith('.dll'))):
        assert p.resolve().parent==internal.resolve()
        p.unlink()
print('Staged native extensions and Windows system-library isolation')
