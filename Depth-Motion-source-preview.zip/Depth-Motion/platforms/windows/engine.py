"""Console helper: Qt captures UTF-8 progress; the desktop app has no console."""
import multiprocessing
import os
from pathlib import Path
import sys

if __name__ == '__main__':
    multiprocessing.freeze_support()
    os.environ['PYTHONUTF8'] = '1'
    for stream in (sys.stdout, sys.stderr):
        if stream is not None:
            stream.reconfigure(encoding='utf-8', errors='replace')
    root = Path(getattr(sys, '_MEIPASS', Path(__file__).parent))
    tools = root / 'media-tools'
    os.environ['PATH'] = str(tools) + os.pathsep + os.environ.get('PATH', '')
    if len(sys.argv) > 1 and sys.argv[1] == '--depth-motion-worker':
        sys.argv.pop(1)
        from core.worker import main
    else:
        if len(sys.argv) > 1 and sys.argv[1] == '--depth-motion-cli':
            sys.argv.pop(1)
        from core.cli import main
    sys.exit(main())
