# Depth Motion 0.2.0 Windows test report

**Result: Windows installer built and installed successfully; local model inference, full sequence rendering, and the installed desktop preview workflow passed on this computer.** Tests completed on 5 November 2026. Original Premiere projects were never opened or modified.

## Computer and build

Windows 11 x64, build 26200; approximately 16 GB RAM. Hardware inventory found NVIDIA GeForce GTX 1650 Ti and Intel UHD Graphics. The actual headless OpenGL renderer selected Intel UHD Graphics and completed the tests. AI depth estimation uses the CPU with up to four threads; the installer does not depend on CUDA.

Built from `Depth Motion - Windows build source.zip`, after reading `READ FIRST - Windows.txt`. Python 3.12.14, DepthFlow 1.0.1, ShaderFlow 0.13.0, PySide6 Essentials 6.12.0, PyTorch 2.15.0 CPU, torchvision 0.29.2 CPU, Transformers 5.22.1, PyInstaller 6.22.3, FFmpeg 9.0.2 essentials, Inno Setup 7.1.1. Exact Python versions are pinned in the source archive. Model: Depth Anything V2 Small, revision `5426e4f0f36572d16453bbda7a8389317b1bef99`.

The final installer is approximately 424.5 MB; the uncompressed app is approximately 1.1 GB. It bundles the model and video tools. Installation returned exit code 0, created an uninstall entry, and required no restart. The installed GUI executable, renderer helper, and native torchvision components match the final bundle by SHA256. The installer checksum is in `Installer checksum.json`.

## Timing and video checks

Six original sample illustrations were generated locally. Their filenames include spaces and an accented character. The full installed-renderer test also used a cache path containing an apostrophe and an accented character.

| Test | Resolution and rate | Image durations in frames | Total frames | Exact duration |
|---|---|---|---|---|
| Full source render | 1920 × 1080, 24 fps | 24, 37, 50, 19, 42, 31 | 203 | 203/24 s = 8.458333… s |
| Full installed-renderer render | 1280 × 720, 30000/1001 fps | 17, 31, 49, 23, 41, 13 | 174 | 5.8058 s |
| Preview created through final installed GUI | 1280 × 720, 30000/1001 fps | 17, 31, 49 | 97 | 97097/30000 s = 3.236566… s |

For each output, FFprobe confirmed H.264, yuv420p, the requested dimensions and exact rational frame rate, and zero audio streams. Every decoded frame's hash matched the ordered hashes of the individual rendered clips. Every frame timestamp matched its expected position in the sequence, starting at zero. Stream duration matched the exact frame total divided by sequence frame rate. These checks cover every image boundary, rather than checking only rounded MP4 duration.

All six clips showed movement when comparing first and quarter-cycle frames, including all five motion variants and the repeat of variant one on image six. The generated contact sheets were visually reviewed for framing, orientation, nonblack imagery, and visible movement. JSON verification files and the videos are in `Sample test`.

## Installed application checks

- The final installer completed successfully and its desktop window opened normally.
- The desktop selected the XML sequence and showed 174 frames and 5.806 seconds before rendering.
- The **Create short preview** button opened the save dialog, launched the helper, updated progress through all three images, reached 100%, and displayed **Video ready**. The produced preview then passed the timing and decoded-frame checks above.
- A previously unseen grayscale photograph was rendered by the final installed helper with `HF_HUB_OFFLINE=1` and `TRANSFORMERS_OFFLINE=1`. Its log confirms local model weights loaded; a valid one-frame 30000/1001 fps MP4 was produced. An earlier fresh color-photo test also passed. This avoids relying solely on cached depth maps from the sample illustrations.
- Existing-output protection was tested against the generated preview: the renderer refused to replace it, returned an error, and its SHA256 remained unchanged.
- Nine pre-recorded sample inputs/artifacts remained byte-for-byte unchanged during installed-app tests. The supplied source ZIP also remained unchanged. No `.prproj` file was accessed.
- Seven parser regression tests passed, covering exact unequal durations and NTSC rates, gaps and overlaps, missing images, transitions and extra tracks, malformed XML, disabled tracks/interlacing/trailing gaps, and reused XML file references.

## Windows adaptations and packaging corrections

The GUI uses a separate console helper to capture UTF-8 progress without opening console windows. Media tools and the pinned model are bundled. Windows concat paths and apostrophe escaping were exercised by the full test. EXIF orientation and grayscale images are normalized before inference. Workers explicitly stop the shader file watcher and release their graphics window. Job signatures separate the Windows renderer's cache from old results; incomplete private partial clips can be rebuilt on retry.

Fresh installed-model testing found that the packaging hook omitted torchvision's newer `_C_stable` and `image_stable` native components. They are now explicitly included. Desktop testing also identified an unrelated build-host ICU DLL shadowing Windows' ICU shim. The staging step now removes these bundled system-library overrides, and the installer cleans them from earlier test installations. The final GUI startup, offline model render, and preview were tested after these fixes.

## What remains unverified or unfinished

The app is an unsigned personal prototype, tested on this PC only. Code signing, wider Windows/GPU compatibility tests, and a complete third-party redistribution compliance audit remain outstanding. Notice files were collected, but that is not the same as a full license/source-distribution audit.

The videos were decoded and frame-verified; importing and playing them inside Premiere was not tested. Original Premiere projects were intentionally kept out of the tests. Check alignment and image appearance in your own sequence before final export.

Supported scope remains one uninterrupted, enabled track of still images with progressive square-pixel video. Effects, transforms, opacity, transitions, gaps, video clips, and nested/multiple populated video tracks are not reproduced. Estimated depth can distort difficult edges and does not independently animate characters. The app does not provide cancellation or automatic media relinking.

No additional runtime download is missing for the tested Windows build. The remaining items above concern release readiness and broader validation.
