from pathlib import Path
from PyInstaller.utils.hooks import collect_data_files, collect_submodules, copy_metadata, collect_dynamic_libs

root = Path(SPECPATH)
datas = []
for package in ('depthflow', 'shaderflow', 'imgui_bundle'):
    datas += collect_data_files(package)
for dist in ('depthflow','shaderflow','turbopipe','parsenaut','dearlog','cyclopts'):
    datas += copy_metadata(dist)
datas += [(str(root/'vendor/model'), 'vendor/model')]
binaries = [(str(root/'vendor/win64'/name), 'media-tools') for name in ('ffmpeg.exe','ffprobe.exe')]
# Torchvision 0.29 uses _C_stable/image_stable, loaded through torch.ops rather
# than normal imports; older PyInstaller hooks only know about _C.
binaries += collect_dynamic_libs('torchvision', search_patterns=['*.pyd', '*.dll'])
binaries += collect_dynamic_libs('glfw')
hidden = ['shaderflow.window.headless', 'glcontext.wgl']
for package in ('transformers.models.depth_anything','transformers.models.dpt','transformers.models.dinov2'):
    hidden += collect_submodules(package)
engine_a = Analysis([str(root/'engine.py')], pathex=[str(root)],
    binaries=binaries, datas=datas, hiddenimports=hidden,
    excludes=['tkinter','PySide6','matplotlib','pandas','pytest','IPython'], optimize=0)
engine_pyz = PYZ(engine_a.pure)
engine = EXE(engine_pyz, engine_a.scripts, [], exclude_binaries=True,
    name='DepthMotionEngine', console=True, upx=False)
gui_a = Analysis([str(root/'app.py')], pathex=[str(root)],
    excludes=['torch','torchvision','transformers','depthflow','shaderflow','tkinter'], optimize=0)
gui_pyz = PYZ(gui_a.pure)
gui = EXE(gui_pyz, gui_a.scripts, [], exclude_binaries=True,
    name='Depth Motion', console=False, upx=False)
coll = COLLECT(gui, engine, engine_a.binaries, engine_a.datas, gui_a.binaries, gui_a.datas,
    strip=False, upx=False, name='Depth Motion')
