"""Add a background-only helper bundle to the already built Mac app."""
import os
import plistlib
import shutil
import subprocess
from pathlib import Path

app = Path('dist-fixed/Depth Motion.app').resolve()
contents = app / 'Contents'
helper = contents / 'Helpers' / 'Depth Motion Helper.app'
helper_contents = helper / 'Contents'
(helper_contents / 'MacOS').mkdir(parents=True, exist_ok=True)
shutil.copy2(contents / 'MacOS' / 'Depth Motion', helper_contents / 'MacOS' / 'Depth Motion Helper')
for name in ('Frameworks', 'Resources'):
    (helper_contents / name).symlink_to(Path('../../..') / name)
with (helper_contents / 'Info.plist').open('wb') as f:
    plistlib.dump({'CFBundleName': 'Depth Motion Helper', 'CFBundleExecutable': 'Depth Motion Helper',
        'CFBundleIdentifier': 'local.depthmotion.helper', 'CFBundlePackageType': 'APPL',
        'CFBundleVersion': '1', 'LSUIElement': True}, f)
subprocess.run(['codesign', '--force', '--sign', '-', '--options', 'runtime',
                '--entitlements', 'entitlements.plist', str(helper)], check=True)
subprocess.run(['codesign', '--force', '--sign', '-', '--options', 'runtime',
                '--entitlements', 'entitlements.plist', str(app)], check=True)
