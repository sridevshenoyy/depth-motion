from PyInstaller.utils.hooks import collect_all
from pathlib import Path

datas, binaries, hiddenimports = [], [], []
for package in ('depthflow', 'shaderflow', 'transformers', 'torch', 'torchvision'):
    data, bins, hidden = collect_all(package)
    datas += data
    binaries += bins
    hiddenimports += hidden
for name in ('ffmpeg', 'ffprobe'):
    binaries.append((str(Path('vendor/mac-arm64') / name), 'media-tools'))

a = Analysis(['app.py'], pathex=['.'], binaries=binaries, datas=datas,
             hiddenimports=hiddenimports, excludes=['tkinter'], optimize=0)
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name='Depth Motion',
          console=False, argv_emulation=False, codesign_identity='-',
          entitlements_file='entitlements.plist')
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False,
               name='Depth Motion')
app = BUNDLE(coll, name='Depth Motion.app', bundle_identifier='local.depthmotion.app',
             info_plist={'CFBundleShortVersionString': '0.1.0',
                         'NSHighResolutionCapable': True})
