"""Render one clip in an isolated process to avoid GPU state buildup."""
from __future__ import annotations
import argparse
import math


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--image', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--width', type=int, required=True)
    parser.add_argument('--height', type=int, required=True)
    parser.add_argument('--frames', type=int, required=True)
    parser.add_argument('--fps-num', type=int, required=True)
    parser.add_argument('--fps-den', type=int, required=True)
    parser.add_argument('--variant', type=int, required=True)
    args = parser.parse_args()
    from attrs import define
    from depthflow.scene import DepthScene

    @define
    class Motion(DepthScene):
        def update(self):
            t = self.cycle
            self.state.isometric = 0.6
            self.state.steady = 0.3
            if args.variant == 0:
                self.state.offset = (0.45 * math.sin(t + math.pi / 2), 0.45 * math.sin(t))
            elif args.variant == 1:
                self.state.offset = (0.65 * math.sin(t), 0.0)
            elif args.variant == 2:
                self.state.offset = (0.0, 0.55 * math.sin(t))
            elif args.variant == 3:
                self.state.focus = 0.35
                self.state.zoom = 0.97
                self.state.isometric = 0.45 * math.cos(t) + 0.65
                self.state.offset = (0.40 * math.sin(t), 0.0)
            else:
                self.state.offset = (0.40 * math.sin(t + math.pi), 0.35 * math.sin(t + math.pi / 2))

    scene = Motion(backend='headless')
    scene.ffmpeg.h264(preset='veryfast')
    scene.input(image=args.image)
    scene.main(output=args.output, width=args.width, height=args.height,
               fps=args.fps_num / args.fps_den,
               time=args.frames * args.fps_den / args.fps_num, ssaa=1.0)


if __name__ == '__main__':
    main()
