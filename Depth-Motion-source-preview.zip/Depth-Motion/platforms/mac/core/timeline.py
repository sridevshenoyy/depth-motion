"""Read the conservative subset of Premiere's Final Cut Pro 7 XML export.

Rendering is video-only. Audio stays in the user's original Premiere sequence.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from fractions import Fraction
from pathlib import Path
from urllib.parse import unquote, urlsplit
import os
import re
import json
import xml.etree.ElementTree as ET

IMAGE_SUFFIXES = {'.png', '.jpg', '.jpeg', '.webp', '.tif', '.tiff', '.bmp'}


class TimelineError(ValueError):
    pass


@dataclass(frozen=True)
class Clip:
    name: str
    path: str
    start_frame: int
    duration_frames: int


@dataclass(frozen=True)
class Timeline:
    name: str
    width: int
    height: int
    fps_num: int
    fps_den: int
    clips: list[Clip]
    warnings: list[str]

    def dictionary(self):
        return asdict(self)


def _int(node, path, label):
    try:
        return int(node.findtext(path, '').strip())
    except (TypeError, ValueError):
        raise TimelineError(f'Missing or invalid {label}.') from None


def _fps(rate):
    if rate is None:
        raise TimelineError('The sequence frame rate is missing.')
    base = _int(rate, 'timebase', 'frame rate')
    if not 1 <= base <= 120:
        raise TimelineError('The sequence frame rate is unsupported.')
    ntsc = rate.findtext('ntsc', 'FALSE').strip().upper() == 'TRUE'
    return Fraction(base * 1000, 1001) if ntsc else Fraction(base, 1)


def _path_from_url(value):
    url = urlsplit(value.strip())
    if url.scheme.lower() != 'file':
        raise TimelineError(f'Unsupported media location: {value}')
    path = unquote(url.path)
    if url.netloc and url.netloc.lower() != 'localhost':
        if os.name != 'nt':
            raise TimelineError(f'Network media path is unavailable on this computer: {value}')
        path = f'//{url.netloc}{path}'
    if os.name == 'nt' and re.match(r'^/[A-Za-z]:/', path):
        path = path[1:]
    return Path(path)


def sequence_names(xml_path):
    root = ET.parse(xml_path).getroot()
    if root.tag != 'xmeml':
        raise TimelineError('Choose a Final Cut Pro XML exported by Premiere Pro.')
    sequences = [s for s in root.iter('sequence') if s.find('media/video') is not None]
    return [s.findtext('name', 'Untitled') for s in sequences]


def read_timeline(xml_path, sequence_name=None):
    try:
        root = ET.parse(xml_path).getroot()
    except (OSError, ET.ParseError) as exc:
        raise TimelineError(f'Could not read the XML file: {exc}') from exc
    if root.tag != 'xmeml':
        raise TimelineError('Choose a Final Cut Pro XML exported by Premiere Pro.')
    sequences = [s for s in root.iter('sequence') if s.find('media/video') is not None]
    if sequence_name is not None:
        matches = [s for s in sequences if s.findtext('name', 'Untitled') == sequence_name]
        if len(matches) != 1:
            raise TimelineError('The chosen sequence is missing or has a duplicate name.')
        sequence = matches[0]
    elif len(sequences) == 1:
        sequence = sequences[0]
    else:
        raise TimelineError('Choose one sequence from the XML file.')
    video = sequence.find('media/video')
    tracks = video.findall('track')
    populated = [t for t in tracks if t.findall('clipitem') or t.findall('transitionitem')]
    if len(populated) != 1:
        raise TimelineError('Use exactly one video track containing your still images. Multiple video tracks are not supported yet.')
    track = populated[0]
    if track.findall('transitionitem'):
        raise TimelineError('Video transitions are not supported yet. Remove them or use a copy without transitions.')
    if any(child.tag not in {'clipitem', 'enabled', 'locked'} for child in track):
        raise TimelineError('The video track contains an unsupported item.')
    if video.findtext('format/samplecharacteristics/pixelaspectratio', 'square').lower() not in {'square', '1.0', '1'}:
        raise TimelineError('Only square pixels are supported.')
    width = _int(video, 'format/samplecharacteristics/width', 'frame width')
    height = _int(video, 'format/samplecharacteristics/height', 'frame height')
    if width <= 0 or height <= 0 or width % 2 or height % 2:
        raise TimelineError('Use a sequence with positive, even frame dimensions.')
    fps = _fps(sequence.find('rate'))
    # XML frequently uses <file id="..."/> references after the first use.
    definitions = {}
    for f in root.iter('file'):
        if f.get('id') and f.findtext('pathurl'):
            definitions[f.get('id')] = f.findtext('pathurl')
    clips = []
    warnings = []
    current = 0
    for item in track.findall('clipitem'):
        if item.find('sequence') is not None:
            raise TimelineError('Nested sequences are not supported.')
        if item.findtext('enabled', 'TRUE').strip().upper() == 'FALSE':
            raise TimelineError('Disabled video clips are not supported.')
        start = _int(item, 'start', 'clip start')
        end = _int(item, 'end', 'clip end')
        if start != current or end <= start:
            raise TimelineError('The video track must contain consecutive images with no gaps or overlaps.')
        file = item.find('file')
        if file is None:
            raise TimelineError(f"No source file found for {item.findtext('name', 'a clip')}.")
        source = file.findtext('pathurl') or definitions.get(file.get('id'))
        if not source:
            raise TimelineError('A source image is offline or missing from the XML.')
        path = _path_from_url(source)
        if path.suffix.lower() not in IMAGE_SUFFIXES:
            raise TimelineError(f'Only still images are supported: {path.name}')
        if not path.is_file():
            raise TimelineError(f'Cannot find source image: {path}')
        if item.findall('filter'):
            warning = 'Existing video effects, transforms and opacity changes are not reproduced; review the result in Premiere.'
            if warning not in warnings:
                warnings.append(warning)
        clips.append(Clip(item.findtext('name', path.name), str(path.resolve()), start, end-start))
        current = end
    if not clips:
        raise TimelineError('The sequence does not contain any images.')
    warnings.append('Audio is not included in the generated video; keep your original audio in Premiere.')
    return Timeline(sequence.findtext('name', 'Untitled'), width, height, fps.numerator, fps.denominator, clips, warnings)


def read_manifest(path):
    """Validate a manifest made by the Premiere panel; never trust its paths/timings."""
    try:
        data = json.loads(Path(path).read_text(encoding='utf-8'))
        width, height = int(data['width']), int(data['height'])
        num, den = int(data['fps_num']), int(data['fps_den'])
        if width <= 0 or height <= 0 or width % 2 or height % 2 or num <= 0 or den <= 0 or num / den > 120:
            raise TimelineError('The manifest has an unsupported resolution or frame rate.')
        clips, current = [], 0
        for item in data['clips']:
            start, duration = int(item['start_frame']), int(item['duration_frames'])
            source = Path(item['path'])
            if start != current or duration <= 0:
                raise TimelineError('The video track must contain consecutive images with no gaps or overlaps.')
            if source.suffix.lower() not in IMAGE_SUFFIXES or not source.is_file():
                raise TimelineError(f'Cannot find source image: {source}')
            clips.append(Clip(str(item.get('name') or source.name), str(source.resolve()), start, duration))
            current += duration
        if not clips:
            raise TimelineError('The sequence does not contain any images.')
        warnings = list(data.get('warnings', []))
        if not all(isinstance(w, str) for w in warnings):
            raise TimelineError('Invalid manifest warnings.')
        audio_warning = 'Audio is not included in the generated video; keep your original audio in Premiere.'
        if audio_warning not in warnings:
            warnings.append(audio_warning)
        return Timeline(str(data.get('name') or 'Untitled'), width, height, num, den, clips, warnings)
    except TimelineError:
        raise
    except (OSError, KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
        raise TimelineError(f'Could not read the sequence manifest: {exc}') from exc
