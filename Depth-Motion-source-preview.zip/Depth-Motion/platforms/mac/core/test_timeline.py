"""Regression checks for timeline boundaries and unsafe inputs."""
import tempfile
import unittest
from pathlib import Path
from core.timeline import TimelineError, read_timeline


class TimelineTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        (self.root / 'é one.png').write_bytes(b'')
        (self.root / 'two.png').write_bytes(b'')

    def tearDown(self):
        self.tmp.cleanup()

    def write_xml(self, extra_track='', second_start=10, first_file=True, transition=''):
        first_path = (self.root / ('é one.png' if first_file else 'missing.png')).as_uri()
        second_path = (self.root / 'two.png').as_uri()
        xml = f'''<xmeml version="4"><sequence><name>Test</name>
        <rate><timebase>30</timebase><ntsc>TRUE</ntsc></rate><media><video>
        <format><samplecharacteristics><width>1080</width><height>1920</height></samplecharacteristics></format>
        <track><clipitem><name>one</name><start>0</start><end>10</end><file id="a"><pathurl>{first_path}</pathurl></file></clipitem>
        {transition}<clipitem><name>two</name><start>{second_start}</start><end>27</end><file id="b"><pathurl>{second_path}</pathurl></file></clipitem></track>
        {extra_track}</video></media></sequence></xmeml>'''
        file = self.root / 'timeline.xml'
        file.write_text(xml, encoding='utf-8')
        return file

    def test_exact_frame_count_and_ntsc(self):
        timeline = read_timeline(self.write_xml())
        self.assertEqual((timeline.fps_num, timeline.fps_den), (30000, 1001))
        self.assertEqual([c.duration_frames for c in timeline.clips], [10, 17])
        self.assertEqual(Path(timeline.clips[0].path).name, 'é one.png')

    def test_reject_gap_or_overlap(self):
        for start in (9, 11):
            with self.subTest(start=start), self.assertRaises(TimelineError):
                read_timeline(self.write_xml(second_start=start))

    def test_reject_missing_source(self):
        with self.assertRaises(TimelineError):
            read_timeline(self.write_xml(first_file=False))

    def test_reject_transition_and_additional_track(self):
        for kwargs in ({'transition': '<transitionitem/>'}, {'extra_track': '<track><clipitem/></track>'}):
            with self.subTest(kwargs=kwargs), self.assertRaises(TimelineError):
                read_timeline(self.write_xml(**kwargs))


if __name__ == '__main__':
    unittest.main()
