"""Local, frame-accurate depth animation pipeline."""
